<section class="footer pb-3 pt-5">
<div class="container border-bottom pb-2">
<div class="row">
    <div class="col-lg-4 py-3 px-1">
   <img class="border-bottom px-3 pb-3" src="img/logo.png" alt="" style="width:180px">

    <div class="py-4 social_icons">
<a href="#" class="fb"><i class="fa fa-facebook"         aria-hidden  ="true"></i></a>
<a href="#" class="link"><i class="fa fa-linkedin"       aria-hidden  ="true"></i></a>
<a href="#" class="tw"><i class="fa fa-twitter"          aria-hidden  ="true"></i></a>
<a href="#" class="goog"><i class="fa fa-google-plus"    aria-hidden  ="true"></i></a>
</div>

    </div>
    <div class="col-lg-3 py-3">
    <h3>Important Links</h3>
    <ul class="list-unstyled pt-3">
        <li><a href="#">Link1</a></li>
        <li><a href="#">Link2</a></li>
        <li><a href="#">Link3</a></li>
        <li><a href="#">Link4</a></li> 
    </ul>
    </div>
    <div class="col-lg-3 py-3 ">
    <h3>Important Links</h3>
    <ul class="list-unstyled pt-3">
        <li><a href="#">Link1</a></li>
        <li><a href="#">Link2</a></li>
        <li><a href="#">Link3</a></li>
        <li><a href="#">Link4</a></li> 
    </ul>
    </div>
    <div class="col-lg-2 py-3">
    <h3>Important Links</h3>
    <ul class="list-unstyled pt-3">
        <li><a href="#">Link1</a></li>
        <li><a href="#">Link2</a></li>
        <li><a href="#">Link3</a></li>
        <li><a href="#">Link4</a></li> 
    </ul>
    </div>

</div>

</div>
<div class="container py-3" >
    <h6 class="text-light float-left"> <span style="color:#ecbd3b">Codeyati@trando.in</span> All Rights are Reserved</h6>
    <h6 class="text-light float-right"> <a href="#" class="border-right text-light px-3">Location</a> <a href="#" class="border-right text-light px-3">Site</a> <a href="#" class=" text-light px-3">Info</a> </h6>
</div>
</section>